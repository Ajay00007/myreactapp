import React, { useState } from 'react';


import { useNavigate } from 'react-router';
import './home.css';

const Home = () => {

  const nav = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    // Perform validation
    if (username === '') {
      alert('Please enter your username.');
    } else if (password === '') {
      alert('Please enter your password.');
    } else {
      // Perform login logic here
      setError('');
      alert('Login successful!');
      nav("/employees")
    }
  };

  return (
  <div className="login-page">
    <div className='form'>
      <h1>Login</h1>
      <form className='login-form' onSubmit={handleSubmit}>
        <div>
          {/* <label>Username:</label> */}
          <input
            type="text"
            placeholder='Enter User Name'
            value={username}
            onChange={handleUsernameChange}
          />
        </div>
        <br/>
        <div>
          {/* <label>Password:</label> */}
          <input
            type="password"
            placeholder='Enter Password'
            value={password}
            onChange={handlePasswordChange}
          />
        </div>
        {error && <p className="error">{error}</p>}
        <br/>
        <div>
      <button onClick={handleSubmit}>Submit</button>
    </div>
      </form>
    </div>
   </div>
   
  );
};

export default Home;